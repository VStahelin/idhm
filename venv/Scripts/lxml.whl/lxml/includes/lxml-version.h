#ifndef LXML_VERSION_STRING
#define LXML_VERSION_STRING "4.5.2"
#endif
